How to open the java file through the terminal:

1. go into the correct folder by tiping:
	cd AlgDat
2. to execute the file type: 
	java -jar Task5.jar
